#include <iostream>
#include <cstdio>
#include <cstring>


using namespace std;
int main()
{
	char x;
	char ch;
	while(1){
		x=fgetc(stdin);
		if (x == -1) return 0;
		char y[2];
		sprintf(y,"%02X", x);
		cout<<y;
	}
    return 0;
}
