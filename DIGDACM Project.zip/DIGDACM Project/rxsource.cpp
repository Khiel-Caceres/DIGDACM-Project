#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>

using namespace std;

int main(){

	char x;
	string temp;
	bool isFound=false;
	while(1){
		
		x = fgetc(stdin);
		
    	if (x == -1) return 0;
    	
    	if(isFound){
  			temp.clear();
  			temp.push_back(x);
  			isFound=false;
		  }
		else{
			temp.push_back(x);
		}
    	
    	ifstream file("huffman-table.txt");
  		string str;
  		while (getline(file, str)) {
  			string huffman = str.substr(5,(str.size()-5));
  			if(temp==huffman){
  				isFound=true;
  				cout<<str[0];
			  }
  		}
  		
    	
	}
	return 0;
}
