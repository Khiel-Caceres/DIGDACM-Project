#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>

using namespace std;

int main(){

	char x;
	
	while(1){
		
		x = fgetc(stdin);
		
    	if (x == -1) return 0;
    	
    	ifstream file("huffman-table.txt");
  		string str;
  		while (getline(file, str)) {
  			if(x==str[0]){
  				cout<<str.substr(5,(str.size()-5));
			  }
  		}
	}
	return 0;
}
