/*
Channel coding at receiver side. 
Error detection method: Checksum (start from header to FCS).
Input: Frames in hexadecimal format from Framing block (2-digit HEX char per byte).
Output: If no error detected, payload or data part of the frame in bit values
        as characters of '0' or '1'. Otherwise, display an error message to stderr.
Frame details:
    data block = 40 bits
    preamble = 16 bits
    header = 16 bits
    fcs = 8 bits
*/

#include <stdio.h>
#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

/* Function prototypes */
const char* hexToBinary(char hex);

int main() {
    // Frame details
    const int frameSize = 80;  // max # bits inside a frame
    const int fcs = 8;  // # of bits for FCS & for each block
    const int preamble = 16;  // # of bits in frame's preamble
    const int header = 16;  // # of bits in frame's header

    char x;
    int ctr = 0;  // counter indicating nth HEX value in a frame; to be reset per frame
    char block1[fcs+1] = "";  // char array with length of fcs; for 1st data block
    char block2[fcs+1] = "";  // +1 for the end of string character
    char checksum[fcs+1] = "";

    string output;
    string finalOutput;
    char temp[5];
    
    // Loop through each HEX value in stdin.
    while (1) {
        temp[0] = '\0';  // clear temp

        x = fgetc(stdin);  // Input from framing block in HEX.

        if (x == -1) {
            // Trim trailing bytes of zeroes (bits padded to fulfill payload size)
            while (!finalOutput.compare(finalOutput.length()-8, string::npos, "00000000")) {
                finalOutput.erase(finalOutput.length()-8);
            }
            cout << finalOutput;
            return 0; // End program when end of line reached.
        }

        // When counter is < the # of HEX digits for preamble, current x is part of preamble.
        if (ctr < preamble/4) {
            for (int i=0; i<preamble/4-1; i++) {  // get succeeding values for preamble
                fgetc(stdin);
            }
            ctr = preamble/4;
        } 
        // When counter is less than the # of HEX digits in a frame prior FCS 
        // (header and data bits), continue calculation for checksum.
        else if (ctr < (frameSize-fcs)/4) {
            strcat(temp, hexToBinary(x));  // Convert x to hex.
            // Check if current HEX value is part of payload, if so, append to output. 
            if (ctr >= (preamble+header)/4) {
                output.append(temp);
            }

            // Check if 1st data block is incomplete, if so, append value to first block, 
            // otherwise, append to 2nd block.
            if (strlen(block1) < fcs) {
                strcat(block1, temp);
                ctr++;
            } else if (strlen(block2) < fcs) {
                strcat(block2, temp);
                ctr++;
            }

            // Check if both data blocks are filled, if so, XOR them 
            // to get the partial checksum and store the it in the 1st data block 
            // while emptying the 2nd data block.
            if (strlen(block1) == fcs && strlen(block2) == fcs) {
                // Calculate for partial checksum
                for (int i=0; i<fcs; i++) {
                    // XOR operation: if both are of the same value then 0, else 1
                    block1[i] = ((block1[i] == block2[i]) ? '0' : '1');
                }
                block2[0] = '\0';  // clear block2
            }
        }
        // When counter is at the beginning of FCS, 
        // retrieve the whole FCS and compare to our calculated checksum.
        else if (ctr == (frameSize-fcs)/4) {
            strcat(checksum, hexToBinary(x));
            // get the succeeding HEX values for FCS (checksum) from stdin
            for(int i=0; i<fcs/4-1; i++) {
                x = fgetc(stdin);
                strcat(checksum, hexToBinary(x));
            }
            // Check if checksum == our calculated checksum (stored in block1), 
            // if so, no error; otherwise, output error message to stderr.
            if (strcmp(checksum, block1) == 0) {
                finalOutput.append(output);
            } else {  
                fprintf(stderr, "Error detected.");
                return 0;
            }
            // Reset everything for this frame in preparation to for next frame
            ctr = 0;
            block1[0] = '\0';
            block2[0] = '\0';
            checksum[0] = '\0';
            output.clear();
        }
    }
    return 0;
}


// Function for converting a hexadecimal value to binary bits.
const char* hexToBinary(char hex) {
    if (hex == '0') return "0000";
    else if (hex == '1') return "0001";
    else if (hex == '2') return "0010";
    else if (hex == '3') return "0011";
    else if (hex == '4') return "0100";
    else if (hex == '5') return "0101";
    else if (hex == '6') return "0110";
    else if (hex == '7') return "0111";
    else if (hex == '8') return "1000";
    else if (hex == '9') return "1001";
    else if (hex == 'a' || hex == 'A') return "1010";
    else if (hex == 'b' || hex == 'B') return "1011";
    else if (hex == 'c' || hex == 'C') return "1100";
    else if (hex == 'd' || hex == 'D') return "1101";
    else if (hex == 'e' || hex == 'E') return "1110";
    else if (hex == 'f' || hex == 'F') return "1111";
    else return "";
}
