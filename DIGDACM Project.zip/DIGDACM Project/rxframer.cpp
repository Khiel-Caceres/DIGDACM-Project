#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
const int blocksize=328;
char block[blocksize+24];
int i = 0;

void deframe() {
	int j;
	for (j = 0; j < i; j++)
	{
		if (block[j]=='0') {
			fprintf(stdout, "%s", "0000");
		}
		else if (block[j]=='1') {
			fprintf(stdout, "%s", "0001");
		}
		else if (block[j]=='2') {
			fprintf(stdout, "%s", "0010");
		}
		else if (block[j]=='3') {
			fprintf(stdout, "%s", "0011");
		}
		else if (block[j]=='4') {
			fprintf(stdout, "%s", "0100");
		}
		else if (block[j]=='5') {
			fprintf(stdout, "%s", "0101");
		}
		else if (block[j]=='6') {
			fprintf(stdout, "%s", "0110");
		}
		else if (block[j]=='7') {
			fprintf(stdout, "%s", "0111");
		}
		else if (block[j]=='8') {
			fprintf(stdout, "%s", "1000");
		}
		else if (block[j]=='9') {
			fprintf(stdout, "%s", "1001");
		}
		else if (block[j]=='A') {
			fprintf(stdout, "%s", "1010");
		}
		else if (block[j]=='B') {
			fprintf(stdout, "%s", "1011");
		}
		else if (block[j]=='C') {
			fprintf(stdout, "%s", "1100");
		}
		else if (block[j]=='D') {
			fprintf(stdout, "%s", "1101");
		}
		else if (block[j]=='E') {
			fprintf(stdout, "%s", "1110");
		}
		else if (block[j]=='F') {
			fprintf(stdout, "%s", "1111");
		}
	}
}


int main() {
	char c;
	while (1) 
	{
		c=fgetc(stdin);
		
		if (c!=-1)
		{
			if (i<(blocksize+24))
			{
         		block[i]=c;
         		i++;
		 	}
         	else
			{
         		deframe();
				i=0;
				block[i]=c;
				i++;
		 	}
		}
		
		else
		{
			deframe();
			return 0;
		}
	}
	
	
	
}
