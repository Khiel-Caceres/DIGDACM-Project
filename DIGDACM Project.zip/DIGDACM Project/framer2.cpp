#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

const int blocksize=40;
char block[blocksize+40];
char preamble[16] = {'C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C'};
char header[16] = {'1','0','0','0','0','0','0','0','1','0','0','0','0','0','0','1'};
char trailer[8] = {'0','0','0','0','0','0','0','0'};

char hex[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

int i = 32, pr = 16;

void frame(){
	int j, k=3, x=0, bit;
	
	int count = 0;
	
	for (j = 0; j < 16; j++) {
		block[j] = preamble[j];
	}
	
	for (j = 0; j < 16; j++) 
		block[j+pr] = header[j];
		
	for ( j = 0; j < 8; j++) 
		block[i+j] = trailer[j];
		
	for ( j = 0; j < blocksize+40; j++)
	{
		if (block[j]=='C')
		{
			if (count==2)
				bit = 0;
			else
				bit = 1;
			count++;

				

		}
		
		else if(block[j] == '0')
			bit = 0;
			
		else if(block[j] == '1')
			bit = 1;
			
		x+=pow(2,k)*bit;
		k--;
		
		if (k==-1)
		{
			fprintf(stdout, "%c", hex[x]);
			k = 3;
			x = 0;
			count = 0;
		}
	}
		//printf("Count is %d\n", count);

}

int main()
{
	char c;
	int count = 0, j;
	

  	while (1) {
    c = fgetc(stdin);
    
    if (c!=-1) 
	{
        if (i<(blocksize+32)) //maybe this can be 24 instead.
		{
			count++;
         	block[i] = c;
         	i++;
		}
		
        else
		{
         	frame();
			i = 32; //maybe change this to 24.
			block[i] = c;
			i++;
		}
    }
    
    else
	{
		//printf("Count is %d\n", count);
		for (j = 0; j < ((blocksize*2)-(count + 1)); j++) {
			block[i] = '0';
			i++;
		}
	    frame();
	    return 0;
	}
  }
}
