#include <iostream>
#include <cstring>

const char binaryToHex(const char* bin);

int main() {
  char x;
  char temp[5];

  while (1) {
    x=fgetc(stdin);
    if (x!=-1) {
      temp[0] = x;
      // get succeeding 3 bits for converting to HEX
      for (int i=1; i<4; i++) {
        temp[i] = fgetc(stdin);
      }
      printf ("%c", binaryToHex(temp));
      temp[0] = '\0';
    }
    else return 0;
  }
  return 0;
}

// Function for converting a binary to HEX.
const char binaryToHex(const char* bin) {
  if (!strcmp(bin, "0000")) return '0';
  else if (!strcmp(bin, "0001")) return '1';
  else if (!strcmp(bin, "0010")) return '2';
  else if (!strcmp(bin, "0011")) return '3';
  else if (!strcmp(bin, "0100")) return '4';
  else if (!strcmp(bin, "0101")) return '5';
  else if (!strcmp(bin, "0110")) return '6';
  else if (!strcmp(bin, "0111")) return '7';
  else if (!strcmp(bin, "1000")) return '8';
  else if (!strcmp(bin, "1001")) return '9';
  else if (!strcmp(bin, "1010")) return 'A';
  else if (!strcmp(bin, "1011")) return 'B';
  else if (!strcmp(bin, "1100")) return 'C';
  else if (!strcmp(bin, "1101")) return 'D';
  else if (!strcmp(bin, "1110")) return 'E';
  else if (!strcmp(bin, "1111")) return 'F';
  else return '\0';
}
