#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <string>

using namespace std;

int main() {
  unsigned char x;
  int frames = 2;  // # of frames
  int size = 72;  // max # of bits per frame
  int fcs = 8;  // # of bits for FCS

  srand(time(NULL));

  // Generate frames in HEX
  for (int i=0; i<frames; i++) {
    for (int i=0; i < (size-fcs)/4; i++) {  // preamble, header, and data bits
      x=rand()%15;
      if (x<10) {
        cout << x;
      } else {
        switch (x) {
          case 10:
            cout << "A";
            break;
          case 11:
            cout << "B";
            break;
          case 12:
            cout << "C";
            break;
          case 13:
            cout << "D";
            break;
          case 14:
            cout << "E";
            break;
          case 15:
            cout << "F";
            break;
        }
      }
    }
    for (int i=0; i<fcs/4; i++) {  // fcs dummy code of 1s (or F in hex)
      cout << "F";
    }
  }
  return 0;
}

