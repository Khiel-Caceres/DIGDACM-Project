#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int hex_to_int(char c)
{
    if (c >= 97)
        c = c - 32;
    int first = c / 16 - 3;
    int second = c % 16;
    int result = first * 10 + second;
    if (result > 9) result--;
    return result;
}

int hex_to_ascii(char c, char d){
        int high = hex_to_int(c) * 16;
        int low = hex_to_int(d);
        return high+low;
}

int main(){

	char x;
	char first;
	char second;
	int count=1;
	char ch;
	
	while(1){
		
		x = fgetc(stdin);
		
		if (x == -1) return 0;
		
		if(count%2==1){
			if(x == ' '){
				continue;
			}
			else{
				first=x;
				count++;
			}
		}
		else{
			if(x == ' '){
				continue;
			}
			else{
				second=x;
				ch=hex_to_ascii(first,second);
				cout<<ch;
				count++;
			}
		}

    	if (x == -1) return 0;
	}
	return 0;
}
